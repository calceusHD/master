/******************************************************************************
*
* Copyright (C) 2013 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/
/*****************************************************************************/
/**
 *
 * @file XLlFifo_polling_example.c
 * This file demonstrates how to use the Streaming fifo driver on the xilinx AXI
 * Streaming FIFO IP.The AXI4-Stream FIFO core allows memory mapped access to a
 * AXI-Stream interface. The core can be used to interface to AXI Streaming IPs
 * similar to the LogiCORE IP AXI Ethernet core, without having to use full DMA
 * solution.
 *
 * This is the polling example for the FIFO it assumes that at the
 * h/w level FIFO is connected in loopback.In these we write known amount of
 * data to the FIFO and Receive the data and compare with the data transmitted.
 *
 * Note: The TDEST Must be enabled in the H/W design inorder to
 * get correct RDR value.
 *
 * <pre>
 * MODIFICATION HISTORY:
 *
 * Ver   Who  Date     Changes
 * ----- ---- -------- -------------------------------------------------------
 * 3.00a adk 08/10/2013 initial release CR:727787
 * 5.1   ms  01/23/17   Modified xil_printf statement in main function to
 *                      ensure that "Successfully ran" and "Failed" strings
 *                      are available in all examples. This is a fix for
 *                      CR-965028.
 *       ms  04/05/17   Added tabspace for return statements in functions for
 *                      proper documentation and Modified Comment lines
 *                      to consider it as a documentation block while
 *                      generating doxygen.
 * </pre>
 *
 * ***************************************************************************
 */

/***************************** Include Files *********************************/
#include "xparameters.h"
#include "xil_exception.h"
#include "xstreamer.h"
#include "xil_cache.h"
#include "xllfifo.h"
#include "xstatus.h"
#include "xsdps.h"
#include "ff.h"
#include "xgpio.h"
#include "stdio.h"
//#include "xexample.h"
#include <math.h>
#include <stdlib.h>
#include <stdint.h>

#ifdef XPAR_UARTNS550_0_BASEADDR
#include "xuartns550_l.h"       /* to use uartns550 */
#endif

/**************************** Type Definitions *******************************/

/***************** Macros (Inline Functions) Definitions *********************/

#define FIFO_DEV_ID	   	XPAR_AXI_FIFO_0_DEVICE_ID

#define WORD_SIZE 4			/* Size of words in bytes */

#define MAX_PACKET_LEN 4

#define NO_OF_PACKETS 64

#define MAX_DATA_BUFFER_SIZE NO_OF_PACKETS*MAX_PACKET_LEN

#undef DEBUG

#define LLR_BITS 7

/************************** Function Prototypes ******************************/
#ifdef XPAR_UARTNS550_0_BASEADDR
static void Uart550_Setup(void);
#endif

int XLlFifoPollingExample(XLlFifo *InstancePtr, u16 DeviceId);
int TxSend(XLlFifo *InstancePtr, u32 *SourceAddr);
int RxReceive(XLlFifo *InstancePtr, u32 *DestinationAddr, int blocking);
void BuildSourceBuffer(u32 *target);
void do_test(XLlFifo* InstancePtr, double snr_db, uint64_t iterations, double bit_val, uint32_t max_iter);
/************************** Variable Definitions *****************************/
/*
 * Device instance definitions
 */
XLlFifo FifoInstance;
XGpio Gpio0, Gpio1, Gpio2, Gpio3;
//XExample Rng;

uint32_t broken_count;

struct rnd_state {
	uint32_t s1, s2, s3;
};

uint32_t r_s1, r_s2, r_s3;

struct rnd_state taus_state;

u32 SourceBuffer[MAX_DATA_BUFFER_SIZE * WORD_SIZE];
u32 DestinationBuffer[MAX_DATA_BUFFER_SIZE * WORD_SIZE];

/*****************************************************************************/
/**
*
* Main function
*
* This function is the main entry of the Axi FIFO Polling test.
*
* @param	None
*
* @return
*		- XST_SUCCESS if tests pass
* 		- XST_FAILURE if fails.
*
* @note		None
*
******************************************************************************/
int main()
{
	int Status;

	xil_printf("--- Entering main() ---\n\r");
	while (1) {
		Status = XLlFifoPollingExample(&FifoInstance, FIFO_DEV_ID);
	}
	if (Status != XST_SUCCESS) {
		xil_printf("Axi Streaming FIFO Polling Example Test Failed\n\r");
		xil_printf("--- Exiting main() ---\n\r");
		return XST_FAILURE;
	}

	xil_printf("Successfully ran Axi Streaming FIFO Polling Example\n\r");
	xil_printf("--- Exiting main() ---\n\r");

	return XST_SUCCESS;
}



void set_res(int res) {
	if (res) {
		XGpio_DiscreteSet(&Gpio0, 2, (1 << 0));
	} else {
		XGpio_DiscreteClear(&Gpio0, 2, (1 << 0));
	}
}

void set_do_gen(int do_gen) {
	if (do_gen) {
		XGpio_DiscreteSet(&Gpio0, 2, (1 << 1));
	} else {
		XGpio_DiscreteClear(&Gpio0, 2, (1 << 1));
	}
}


static uint32_t random32(struct rnd_state *state)
{
#define TAUSWORTHE(s,a,b,c,d) ((s&c)<<d) ^ (((s <<a) ^ s)>>b)

	state->s1 = TAUSWORTHE(state->s1, 13, 19, 4294967294UL, 12);
	state->s2 = TAUSWORTHE(state->s2, 2, 25, 4294967288UL, 4);
	state->s3 = TAUSWORTHE(state->s3, 3, 11, 4294967280UL, 17);

	return (state->s1 ^ state->s2 ^ state->s3);
}

uint32_t __seed(uint32_t x, uint32_t m)
{
	return (x < m) ? x + m : x;
}

int init_random32_init(struct rnd_state *state, uint32_t val)
{

#define LCG(x)	((x) * 69069)	/* super-duper LCG */
		state->s1 = __seed(LCG(val), 1);
		state->s2 = __seed(LCG(state->s1), 7);
		state->s3 = __seed(LCG(state->s2), 15);

		/* "warm it up" */
		random32(state);
		random32(state);
		random32(state);
		random32(state);
		random32(state);
		random32(state);
	return 0;
}

void write_max_iter(uint32_t max_iter) {
	XGpio_DiscreteWrite(&Gpio0, 1, max_iter);
}

void write_param_1(uint32_t param) {
	XGpio_DiscreteWrite(&Gpio1, 1, param);
}

void write_param_2(uint32_t param) {
	XGpio_DiscreteWrite(&Gpio1, 2, param);
}

void write_preload_data(uint32_t preload1, uint32_t preload2) {
	XGpio_DiscreteWrite(&Gpio2, 1, preload1);
	XGpio_DiscreteWrite(&Gpio3, 2, preload2);
}

void write_sigma_inv(uint32_t sigma_inv) {
	XGpio_DiscreteWrite(&Gpio2, 2, sigma_inv);
}

void set_sigma(double sigma) {
	double tmp = 1.0f / sigma;
	if (tmp > (1 << 4)-2) {
		tmp = (1 << 4)-2;
		xil_printf("overflow");
	}
	write_sigma_inv((int32_t)(tmp * (1 << 27)));
}

void set_bit_val(double bit_val) {
	double tmp = bit_val * (1 << 9);
	//warning: can overflow we are setting a signed variable here
	XGpio_DiscreteClear(&Gpio0, 2, ~((1 << 0) | (1 << 1)));
	XGpio_DiscreteSet(&Gpio0, 2, ((uint32_t)tmp) << 2);
}

void set_sigma_v(double sigma) {
	double tmp = sigma;
	if (tmp > (1 << 7) - 2) {
		tmp = (1 << 7) - 2;
		xil_printf("overflow");
	}
	XGpio_DiscreteWrite(&Gpio3, 1, (int32_t)(tmp * (1 << 24)));
}

void init_gpio(XGpio* res, u16 device_id) {
	XGpio_Config *GPConfig;
	int Status;
	GPConfig = XGpio_LookupConfig(device_id);
	if (!GPConfig) {
		xil_printf("No config found for %d\r\n", device_id);
		return;
	}
	Status = XGpio_CfgInitialize(res, GPConfig, GPConfig->BaseAddress);
	if (Status != XST_SUCCESS) {
		xil_printf("Initialization failed\n\r");
		return;
	}
	XGpio_SetDataDirection(res, 1, 0);
	XGpio_SetDataDirection(res, 2, 0);

}

/*****************************************************************************/
/**
*
* This function demonstrates the usage AXI FIFO
* It does the following:
*       - Set up the output terminal if UART16550 is in the hardware build
*       - Initialize the Axi FIFO Device.
*	- Transmit the data
*	- Receive the data from fifo
*	- Compare the data
*	- Return the result
*
* @param	InstancePtr is a pointer to the instance of the
*		XLlFifo component.
* @param	DeviceId is Device ID of the Axi Fifo Deive instance,
*		typically XPAR_<AXI_FIFO_instance>_DEVICE_ID value from
*		xparameters.h.
*
* @return
*		-XST_SUCCESS to indicate success
*		-XST_FAILURE to indicate failure
*
******************************************************************************/
int XLlFifoPollingExample(XLlFifo *InstancePtr, u16 DeviceId)
{
	XLlFifo_Config *Config;

	int Status;
	int Error;
	FATFS fatfs;
	FIL f;
	Status = XST_SUCCESS;
	volatile int Delay;

	//XExample_Initialize(&Rng, XPAR_EXAMPLE_0_DEVICE_ID);

	//XExample_Set_sigma_V(&Rng, 0); //16, 4
	init_gpio(&Gpio0, XPAR_GPIO_0_DEVICE_ID);
	init_gpio(&Gpio1, XPAR_GPIO_1_DEVICE_ID);
	init_gpio(&Gpio2, XPAR_GPIO_2_DEVICE_ID);
	init_gpio(&Gpio3, XPAR_GPIO_3_DEVICE_ID);

	init_random32_init(&taus_state, 23423);

	//write_max_iter(30);
	//set_res(1);
	//write_preload_data(0xDEADBEEF);
	//set_sigma(0.7f);
	//XExample_Set_sigma_V(&Rng,(uint16_t)(1.5f * (1<<12))); //16 bit total , 4 bit int

	for (Delay = 0; Delay < 10000; Delay++);

	set_res(0);

	for (Delay = 0; Delay < 10000; Delay++);

	/* Initialize the Device Configuration Interface driver */
	Config = XLlFfio_LookupConfig(DeviceId);
	if (!Config) {
		xil_printf("No config found for %d\r\n", DeviceId);
		return XST_FAILURE;
	}

	/*
	 * This is where the virtual address would be used, this example
	 * uses physical address.
	 */
	Status = XLlFifo_CfgInitialize(InstancePtr, Config, Config->BaseAddress);
	if (Status != XST_SUCCESS) {
		xil_printf("Initialization failed\n\r");
		return Status;
	}

	XLlFifo_Reset(InstancePtr);
	int do_file_write = -1;
	/* Check for the Reset value */
	Status = XLlFifo_Status(InstancePtr);
	XLlFifo_IntClear(InstancePtr,0xffffffff);
	Status = XLlFifo_Status(InstancePtr);
	if(Status != 0x0) {
		xil_printf("\n ERROR : Reset value of ISR0 : 0x%x\t"
			    "Expected : 0x0\n\r",
			    XLlFifo_Status(InstancePtr));
		return XST_FAILURE;
	}
	int sigma = 0;
	char* path = "0:/";
	Status = f_mount(&fatfs, path, 0);

	if (Status) {
		do_file_write = 0;
	}

	char file[128];

	int fileno = 0;
	DIR dir;
	FILINFO finf;
	f_opendir(&dir, "0:/");

	while (1) {
		int intt = f_readdir(&dir, &finf);
		if (intt || dir.sect == 0) {
			//xil_printf("error:%d\n", intt);
			break;
		}
		//xil_printf("%s\n", finf.fname);
		long tmpl = atoi(finf.fname);
		if (tmpl > fileno) {
			fileno = tmpl;
		}
	}
	f_closedir(&dir);

	fileno++;

	snprintf(file, 128, "%05dr.txt", fileno);

	Status = f_open(&f, file, FA_CREATE_ALWAYS | FA_WRITE);
	if (Status) {
		do_file_write = 0;
	}
	char tmp[1024];
	int cnt;
	if (do_file_write) {
		xil_printf("writing to file: %s", file);
	}
	init_random32_init(&taus_state, 23423 + fileno);
	//XGpio_DiscreteWrite(&Gpio1, 2, 0);
	xil_printf("snr param1 total_bits error_bits error_rate total_frames error_frames frame_rate\n");
	double param1 = 1.0;
	double bit_val = 1.0;
	int iterations = 50;
	while (1) {
		double snr = 0.0;


		while (1) {
			cnt = snprintf(tmp, 1024, "%f %f ", snr, bit_val);
			xil_printf("%s", tmp);
			if (do_file_write) {
				f_write(&f, tmp, cnt, &Status);
			}
			write_param_1(param1 * 0x40);
			set_bit_val(bit_val);
			do_test(InstancePtr, snr, 100000, bit_val, iterations);
			snr += 0.25;
			if (snr >= 10.001) {
				//param1 += -0.02;
				bit_val += 2;
				//iterations++;
				if (iterations > 100 || param1 < 0.4999 || bit_val >= 61) {
					f_close(&f);
					while (1) {}
				}
				break;
			}
		}
	}
	set_do_gen(1);
	while (1) {

		//xil_printf("loop: %d\n", sigma);
		++sigma;
		/* Revceive the Data Stream */
		Status = RxReceive(InstancePtr, DestinationBuffer, 1);
		if (Status != XST_SUCCESS){
			xil_printf("Receiving data failed");
			return XST_FAILURE;
		}
		xil_printf("errors: %d\n", DestinationBuffer[0]);


	}


	if (Error != 0){
		return XST_FAILURE;
	}

	return Status;
}

void do_test(XLlFifo* InstancePtr, double snr_db, uint64_t iterations, double bit_val, uint32_t max_iter) {
	char tmp[1024];
	set_res(1);

	write_preload_data(random32(&taus_state), random32(&taus_state));
	write_max_iter(max_iter);
	double ebn0 = pow(10, snr_db/10.0f);
	double sigma = sqrt(1 / ebn0);
	//set_sigma(sigma * sigma / 2.0); //sigma for the llr calc
	set_sigma(1.0f);

	set_sigma_v(bit_val * sigma); //sigma for the rng

	for (int Delay = 0; Delay < 10000; Delay++);
	//wait some time
	set_res(0);
	for (int Delay = 0; Delay < 10000; Delay++);

	//generate some values to flush all the pipes
	set_do_gen(1);
	for (int Delay = 0; Delay < 1000; Delay++);
	set_do_gen(0);
	while  (!RxReceive(InstancePtr, DestinationBuffer, 0)) {
	}
	set_res(1);
	for (int Delay = 0; Delay < 10000; Delay++);
	set_res(0);
	for (int Delay = 0; Delay < 10000; Delay++);
	while  (!RxReceive(InstancePtr, DestinationBuffer, 0)) {
	}
	//go for real
	set_do_gen(1);

	uint64_t error_bits = 0, total_bits = 0;
	uint64_t error_frames = 0, total_frames = 0;
	uint64_t i;

	for (i = 0; i < iterations / 8; i++) {
		uint32_t len = RxReceive(InstancePtr, DestinationBuffer, 1);
		for (uint32_t j = 0; j < len; ++j) {	// as the  axi stream rx fifo can't handle length 1 packets in quick succession
										  	//we group them together by 8 and go trough them here
			error_bits += DestinationBuffer[j];
			if (DestinationBuffer[j]) {
				++error_frames;
			}
			total_frames += 1;
			total_bits += 648;
			if (error_frames > 2000) {
				goto done;
			}
		}
	}
	done:
	snprintf(tmp, 1024, "%llu %llu %E %llu %llu %E", total_bits, error_bits, ((double)error_bits)/((double)total_bits), total_frames, error_frames, (double)error_frames/(double)total_frames);
	xil_printf("%s\n", tmp);
}

/*****************************************************************************/
/**
*
* RxReceive routine.It will receive the data from the FIFO.
*
* @param	InstancePtr is a pointer to the instance of the
*		XLlFifo instance.
*
* @param	DestinationAddr is the address where to copy the received data.
*
* @return
*		-XST_SUCCESS to indicate success
*		-XST_FAILURE to indicate failure
*
* @note		None
*
******************************************************************************/
int RxReceive (XLlFifo *InstancePtr, u32* DestinationAddr, int blocking)
{
	int Status;
	static u32 ReceiveLength;

	//xil_printf(" Receiving data ....\n\r");
	if (blocking) {
		while (!XLlFifo_RxOccupancy(InstancePtr)) {
		}
	} else {
		if (!XLlFifo_RxOccupancy(InstancePtr)) {
			return -1;
		}
	}


	/* Read Recieve Length */
	ReceiveLength = XStrm_RxGetLen(&InstancePtr->RxStreamer);
	//ReceiveLength = (XLlFifo_iRxGetLen(InstancePtr))/WORD_SIZE;
	//xil_printf("imma receive %d words\n", ReceiveLength);
	/* Start Receiving */
	//ReceiveLength = 4;

	XStrm_Read(&InstancePtr->RxStreamer, DestinationAddr, ReceiveLength);

	Status = XLlFifo_IsRxDone(InstancePtr);
	if(Status != TRUE){
		xil_printf("Failing in receive complete ... \r\n");
		return XST_FAILURE;
	}

	return ReceiveLength / 4;
}
